<?php
/*
Plugin Name: AntiLeech
Plugin URI: http://redalt.com/Resources/Plugins/AntiLeech
Description: Prevent errant parties from stealing your content and bandwidth.
Author: Owen Winkler
Version: 1.8
Author URI: http://asymptomatic.net
*/ 

load_plugin_textdomain('antileech', dirname(plugin_basename(__FILE__)));

if(!function_exists('stripos')) {
	function stripos($haystack, $needle, $offset = 0) {
		return @strpos(strtolower($haystack), strtolower($needle), $offset);
	}
}

class AntiLeech {
	function AntiLeech() {
		add_action('init', array(&$this, 'init'));
		add_action('template_redirect', array(&$this, 'template_redirect'));
		add_action('the_content', array(&$this, 'the_content'));
		add_action('do_robots', array(&$this, 'do_robots'));
		add_action('admin_menu', array(&$this, 'admin_menu'));
		add_action('post_link', array(&$this, 'post_link'));
		add_action('option_rss_use_excerpt', array(&$this, 'option_rss_use_excerpt'));
		add_action('pre_get_posts', array(&$this, 'pre_get_posts'));
		add_action('the_posts', array(&$this, 'the_posts'));
	}
	
	function init() {
		$options = get_option('antileech');
		$this->route = false;
		
		
		foreach((array)$options['blockip'] as $ip => $doroute) {
			if(stripos($_SERVER['REMOTE_ADDR'], $ip) !== false ) {
				$this->route = $doroute;
				break;
			}
		}
		if(!$this->route) {
			foreach((array)$options['blockua'] as $ua => $doroute) {
				if(stripos($_SERVER['HTTP_USER_AGENT'], $ua) !== false ) {
					$this->route = $doroute;
					break;
				}
			}
		}
		
		if(preg_match('/^\/' . $this->get_img_prefix() . '\/([0-9a-f]{8})\/(.*)\.gif$/i', $_SERVER['REQUEST_URI'], $matches)) {
			$ip = urldecode($matches[1]);
			$ua = urldecode($matches[2]);
			if(empty($options['detectedua'][$ua])) {
				$options['detectedua'][$ua] = $_SERVER['HTTP_REFERER'];
				update_option('antileech', $options);
			}
			
			header('content-type: image/gif');
			die( base64_decode('R0lGODlhZAAKAJEAAP///5mZmf///wAAACH5BAEHAAIALAAAAABkAAoAAAJllI+py+0Po5y02huB3kDwvxng6H3YSWlBoG4ssLJy58Xwqr5wi/bQvsMBgTOR7tgi0nxMxQ03Y9Va0hoU+olVm1wjNddR6oZI5a6LFrvCL5nQZrutz2juKKwp3fccfagOGCjYVQAAOw=='));
		}
	}
	
	function get_img_prefix()
	{
	 	return substr(md5(get_bloginfo('home') . 'AntiLeech'), 1, 8);
	}
	
	function lorem_pgraph($seed)
	{
		$start = array("Nam quis nulla", "Integer malesuada", "In an enim", "Sed vel lectus", "Donec odio urna,", "Phasellus rhoncus", "Aenean id ", "Vestibulum fermentum", "Pellentesque ipsum",  "Nulla non", "Proin in tellus", "Vivamus luctus", "Maecenas sollicitudin", "Etiam egestas", "Lorem ipsum dolor sit amet,", "Nullam feugiat,", "Aliquam erat volutpat", "Mauris pretium",);
		$mid = array(" a arcu imperdiet", " tempus molestie,", " porttitor ut,", " iaculis quis,", " metus id velit", " lacinia neque", " sed nisl molestie", " sit amet nibh", " consectetuer adipiscing", " turpis at pulvinar vulputate,", " erat libero tristique tellus,", " nec bibendum odio risus"," pretium quam", " ullamcorper nec,", " rutrum non,", " nonummy ac,", " augue id magna",);
		$end = array(" nulla.  "," malesuada.  "," lectus.  "," sem.  "," pulvinar.  "," faucibus fringilla.  "," dignissim sagittis.  "," egestas leo.  "," metus.  "," erat.  "," elit.  "," sit amet ante.  "," volutpat.  "," urna.  "," rutrum.  ",);
	
		$ipsum_text = '';
		srand($seed);
		$lines = rand(1,6);
		for($l = 0; $l < $lines; $l++) {
			$line = $start[rand(0,count($start))];
			$mids = rand(1,3);
			for($z = 0; $z < $mids; $z++) $line .= $mid[rand(0,count($mid))];
			$line .= $end[rand(0,count($end))];
			$ipsum_text .= $line;
		} 
		$ipsum_text .= "\n\n";
		return $ipsum_text;	
	}
	
	function get_theft_line($l, $url, $user) {
		$options = get_option('antileech');
		$lines = array(
			"Is this site attempting to steal <a href=\"$url\">{$user}</a>'s content?  It seems like it.",
			"<a href=\"$url\">{$user}</a> never authorized this site to copy this site content, but it looks like they did it anyway.",
			"The copyright on <a href=\"$url\">{$user}</a>'s work doesn't extend to the owner of this site.",
			"If you want a copy of <a href=\"$url\">{$user}</a>'s content, you really ought to ask first.",
			"If you see advertising on this page, <a href=\"$url\">{$user}</a> - the author of this content - probably isn't seeing any of that revenue.",
			"Did this site obtain <a href=\"$url\">{$user}</a>'s permission to re-publish this content?  No!",
			"Here's just another instance of someone trying to make a buck by taking <a href=\"$url\">{$user}</a>'s content without permission.",
			"Where is justice in the world when this site steals <a href=\"$url\">{$user}</a>'s original, copyrighted works?",
			"Aren't you sick of this site stealing <a href=\"$url\">{$user}</a>'s content for their own use?",
			"But wait, who does this content really belong to?  Not this site, but <a href=\"$url\">{$user}</a>, from whom they stole it!", 
		);
		$output = $lines[$l % count($lines)];
		if(isset($options['nolinks'])) return strip_tags($output);
		return $output;
	}
	
	function feedburner_redirect($remote) {
		if (function_exists('status_header')) status_header(307);
		header("HTTP/1.1 307 Temporary Redirect");
		header("Location: $remote");
		exit;
	}
	
	function get_cat_by_name($name) {
    global $cache_categories;
		$cat_paths = '/' . trim(urldecode($name), '/');
		$name = sanitize_title(basename($cat_paths));
		$cat_paths = explode('/', $cat_paths);
		foreach($cat_paths as $pathdir)
			$cat_path .= ($pathdir!=''?'/':'') . sanitize_title($pathdir);
		
		$all_cat_ids = get_all_category_ids();
		$fcat = 0; 
		$partial_match = 0;
		foreach ( $all_cat_ids as $cat_id ) {
			$cat = get_category($cat_id);
			if ( $cat->fullpath == $cat_path ) {
				$fcat = $cat_id;
				break;
			} elseif ( $cat->category_nicename == $name ) {
				$partial_match = $cat_id;
			}
		}
		
		if (!$fcat && $partial_match) {
			$fcat = $partial_match;
		}
		return $fcat;
	}
	
	function feedburner_detect($options, $wp_query) {
		if(stripos($_SERVER['HTTP_USER_AGENT'], 'FeedBurner') === false) {
			krsort($options);
			foreach($options as $local => $remote) {
				switch($local{0}) {
				case '*':
					$this->feedburner_redirect($remote);
					break;
				case 'c':
					$cat = intval(substr($local, 1));
					if(isset($wp_query->query_vars['cat'])) {
						$acat = $wp_query->query_vars['cat'];
					}
					else {
						$acat = $this->get_cat_by_name($wp_query->query_vars['category_name']); 
					}
					if($cat == $acat) $this->feedburner_redirect($remote);
					//if($wp_query->query_vars['cat'] == $cat) $this->feedburner_redirect($remote);
					break;
				case 'o':
					if($wp_query->query_vars['withcomments'] == 1) $this->feedburner_redirect($remote);
					break;
				case 'p':
					if(!is_single() && !is_category() && ($wp_query->query_vars['withcomments'] != 1)) $this->feedburner_redirect($remote);
					break;
				}
			}
		}
	}
	
	function pre_get_posts($wpquery) {
		global $wp_query;
		$options = get_option('antileech');

		if(!$this->route && is_feed() && isset($options['burnedfeeds'])) {
			$this->feedburner_detect($options['burnedfeeds'], $wp_query);
		}

		return $wpquery;
	}
		
	function template_redirect() {
		$options = get_option('antileech');
		
		if(!function_exists('is_robots') && preg_match('/^\/robots.txt$/i', $_SERVER['REQUEST_URI'])) {
			header('content-type: text/plain');
			do_action('do_robots');
			exit;
		}
	}
	
	function the_posts($posts) {
		if($this->route) {
			$options = get_option('antileech');
			$sitename = get_bloginfo('name');
			$siteurl = get_bloginfo('home');
		
			foreach($posts as $post) {
				foreach($post as $member => $value) {
					$newpost->$member = $value;
				}
				$authordata = get_userdata($post->post_author);
				$author = $authordata->user_nicename;
				$permalink = get_permalink($post->ID);

				switch($options['contentis']) {
				case 'text':
					$newpost->post_content = $options['itemtext'];
					break;
				case 'truncated':
					$newpost->post_content = $newpost->post_content; 
					break;
				case 'generated':
				default:
					$newpost->post_content = $this->get_theft_line($post->ID, $siteurl, $author) . "\n\n";
					$newpost->post_content .= "Visit <a href=\"{$permalink}\">{$post->post_title}</a> at <a href=\"{$siteurl}\">{$sitename}</a> to get the actual content of this post, or to ask for permission to redistribute that content.\n\n";
					$newpost->post_content .= $this->lorem_pgraph($newpost->ID);
					$newpost->post_content .= "\n\nProtect your WordPress content from theft with the <a href=\"http://redalt.com/Resources/Plugins/AntiLeech\">AntiLeech</a> plugin, written by <a href=\"http://asymptomatic.net\">Owen</a>, and provided for free."; 
				}
				if(isset($options['nolinks'])) {
					$newpost->post_content = strip_tags($newpost->post_content);
				}  
				$newpost->post_excerpt = '';
				$newposts[] = $newpost;
				unset($newpost);
			}
			$posts = $newposts;
		}
		return $posts;
	}
	
	function the_content($content) {
		$options = get_option('antileech');
		if($this->route && !isset($options['noiframeremoval'])) {
			$payload = '<script type="text/javascript">function alAddLoadEvent(func) {if ( typeof alOnload!="function"){alOnload=func;}else{ var oldonload=alOnload;alOnload=function(){oldonload();func();}}}alAddLoadEvent(function() {var ifr = document.getElementsByTagName("iframe");for(var i in ifr)i.src = "about:blank";});</script>';
			$content .= $payload;
		}
		if (is_feed() && !isset($options['noleechimage'])) {
			$content .= '<img src="' . get_bloginfo('home') . '/' . $this->get_img_prefix() . '/' . dechex(ip2long($_SERVER['REMOTE_ADDR'])) . '/' . $_SERVER['HTTP_USER_AGENT'] . '.gif" />';
		}
		return $content;
	}
	
	function do_robots() {
		$options = get_option('antileech');

		foreach((array)$options['blockua'] as $ua => $doroute) {
			echo "User-agent: {$ua}\nDisallow: /\n";
			list($nua) = explode('/', $ua, 1);
			if($nua != $ua) echo "User-agent: {$ua}\nDisallow: /\n";			
		}
	}
	
	function admin_menu() {
		add_options_page('AntiLeech', 'AntiLeech', 'manage_options', __FILE__, array(&$this, 'options_page')); 
	}
	
	function options_page() {
		global $wpdb;
		
		if(!current_user_can('manage_options')) die('No cheating.');
	
		$options = get_option('antileech');
		if($options['contentis'] == '') $options['contentis'] = 'generated';
		
		if(isset($_POST['submit'])) {
			check_admin_referer('antileech');
		
			foreach((array)$_POST['uas'] as $ua) {
				$newuas[urldecode($ua)] = 1;
			}
			$options['blockua'] = $newuas;
			
			if($_POST['newua'] != '') {
				foreach((array)$options['blockua'] as $ua => $doroute) {
					if(stripos($ua, $_POST['newua']) === false) {
						$newblockuas[$ua] = $doroute;
					}
				}
				foreach((array)$options['detectedua'] as $ua => $refip) {
					if(stripos($ua, $_POST['newua']) === false) {
						$newdetecteduas[$ua] = $refip;
					}
				}
				$newblockuas[$_POST['newua']] = 1;
				$options['blockua'] = $newblockuas;
				$options['detectedua'] = $newdetecteduas;
			}
			if($_POST['delua'] != '') {
				$newblockuas = array();
				$newdetecteduas = array();
				foreach((array)$options['blockua'] as $ua => $doroute) {
					if(stripos($ua, $_POST['delua']) === false) {
						$newblockuas[$ua] = $doroute;
					}
				}
				foreach((array)$options['detectedua'] as $ua => $refip) {
					if(stripos($ua, $_POST['delua']) === false) {
						$newdetecteduas[$ua] = $refip;
					}
				}
				$options['blockua'] = $newblockuas;
				$options['detectedua'] = $newdetecteduas;
			}
			foreach((array)$_POST['ips'] as $ip) {
				$newips[$ip] = 1;
			}
			$options['blockip'] = $newips;
			if($_POST['newip'] != '') {
				$options['blockip'][$_POST['newip']] = 1;
			}
			foreach(array('noleechimage', 'nolinks', 'nomainlink', 'noiframeremoval') as $toggle) {
				if(isset($_POST[$toggle])) {
					$options[$toggle] = true;
				}
				else {
					unset($options[$toggle]);
				}
			}
			$options['contentis'] = $_POST['contentis'];
			$options['itemtext'] = $_POST['itemtext'];
			
			$newburns = array();
			foreach((array)$options['burnedfeeds'] as $local => $remote) {
				if(isset($_POST['feed'][$local])) {
					$newburns[$local] = $remote;
				}
			}
			$options['burnedfeeds'] = $newburns;
			if($_POST['newfburl'] != '') {
				$options['burnedfeeds'][$_POST['newlocalurl']] = $_POST['newfburl'];
			}
			
			update_option('antileech', $options);
			
			echo '<div id="message" class="updated fade"><p><strong>' . __('Options saved.', 'antileech') . '</strong></p></div>';
		}
		
		?>
		<div class="wrap"> 
		<h2><?php _e('AntiLeech Settings', 'antileech'); ?></h2> 
		<form method="post">
		<?php _e("<p>Set these options to prevent certain User-Agents and IP addresses from stealing your content via RSS.</p><p>All items will test positive if found to be a substring.  For example, entering \"ABC\" will test positive against all User-Agents that contain \"ABC\", such as \"Browser ABC/1.1\".</p>", 'antileech'); ?>
		
		<fieldset class="options">
		<legend><?php _E('Observed User Agents', 'antileech'); ?></legend>
		<?php _e("<p>Place a check next to User-Agents that should receive \"faux\" content.</p>", 'antileech'); ?>		
		<ul>
		<?php
		$none = true;
		foreach((array)$options['detectedua'] as $ua => $refip) {
			$uas[] = $ua;
		}
		foreach((array)$options['blockua'] as $ua => $doroute) {
			$uas[] = $ua;
		}
		if(is_array($uas)) {
			$uas = array_unique($uas);
			sort($uas);
		}
		foreach((array)$uas as $ua) {
			$checked = isset($options['blockua'][$ua]) ? ' checked="checked"' : '';
			echo "<li><label><input type=\"checkbox\" name=\"uas[]\" value=\"" . urlencode($ua) ."\" {$checked}/> <strong>{$ua}</strong></label>";
			if(isset($options['detectedua'][$ua])) {
				echo " <small>" . sprintf(__('Referred by: %s', 'antileech'), $options['detectedua'][$ua]) . "</small>";
			}
			echo "</li>\n";
			$none = false; 
		}
		if($none) echo "<li>" . __('No User-Agents have been detected leeching your content yet.') . "</li>";
		?>
		</ul>
		<p><?php printf(__('<label>Add this User-Agent:%s</label>'), '<input type="text" name="newua" value="" />'); ?></p>
		<p><?php printf(__('<label>Remove User-Agents that match:%s</label>'), '<input type="text" name="delua" value="" />'); ?></p>
		</fieldset>
		<p class="submit"><input type="submit" name="submit" value="Update" /></p>

		<fieldset class="options">
		<legend><?php _E('IP Addresses', 'antileech'); ?></legend>
		<?php _e("<p>Clear the check next to an IP Address to remove it from the list that should receive \"faux\" content.  Use the text box to input a new IP address to add to the list.</p>", 'antileech'); ?>		
		<ul>
		<?php

		$none = true;		
		foreach((array)$options['blockip'] as $ip => $doroute) {
			echo "<li><label><input type=\"checkbox\" name=\"ips[]\" value=\"{$ip}\" checked=\"checked\"/> <strong>{$ip}</strong></label></li>\n";
			$none = false; 
		}
		if($none) echo "<li>" . __('No IP addresses have been added yet.') . "</li>";
		
		?>
		</ul>
		<p><?php printf(__('<label>Add this IP address:%s</label>'), '<input type="text" name="newip" value="" />'); ?></p>
		</fieldset>
		<p class="submit"><input type="submit" name="submit" value="Update" /></p>
		<fieldset class="options">
		<legend><?php _E('Output Control', 'antileech'); ?></legend>
		<?php _e("<p>These options specify what happens in the output to qualifying User-Agents or IP Addresses.</p>", 'antileech'); ?>		
		<ul>
			<?php $checked = isset($options['noleechimage']) ? 'checked = "checked"' : ''; ?>
			<li><?php printf(__('<label>%s Do not insert the AntiLeech image for detecting leechers into feed output.</label>'), '<input type="checkbox" name="noleechimage" value="" ' . $checked . '/>'); ?></li>
			<?php $checked = isset($options['nolinks']) ? 'checked = "checked"' : ''; ?>
			<li><?php printf(__('<label>%s Do not link to my blog inside the generated posts.</label>'), '<input type="checkbox" name="nolinks" value="" ' . $checked . '/>'); ?></li>
			<?php $checked = isset($options['nomainlink']) ? 'checked = "checked"' : ''; ?>
			<li><?php printf(__('<label>%s Do not publish the correct link (in the &lt;link&gt; tag) in my blog\'s RSS.</label>'), '<input type="checkbox" name="nomainlink" value="" ' . $checked . '/>'); ?></li>
			<?php $checked = isset($options['noiframeremoval']) ? 'checked = "checked"' : ''; ?>
			<li><?php printf(__('<label>%s Do not attempt to remove AdSense iframes with javascript on remote pages that display feed output.</label>'), '<input type="checkbox" name="noiframeremoval" value="" ' . $checked . '/>'); ?></li>
			<li><?php 
			$ci = array('generated'=>'','truncated'=>'','text'=>'');
			$ci[$options['contentis']] = 'checked="checked"';
			printf(__('Posts in feeds appear to leeching bots as: <ul><li><label>%1s Generated Content</label></li><li><label>%2s Truncated Content</label></li><li><label>%3s This text:</label> %4s</li>'), 
				'<input type="radio" name="contentis" value="generated" ' . $ci['generated'] . '/>',
				'<input type="radio" name="contentis" value="truncated" ' . $ci['truncated'] . '/>',
				'<input type="radio" name="contentis" value="text" ' . $ci['text'] . '/>',
				'<textarea name="itemtext">' . htmlentities(stripslashes($options['itemtext'])) . '</textarea>'
			); ?></li>
		</ul>
		</fieldset>

		<p class="submit"><input type="submit" name="submit" value="Update" /></p>

		<fieldset class="options">
		<legend><?php _e('FeedBurner Redirects', 'antileech'); ?></legend>
		<?php _e("<p>Use these options to redirect all feed requests to a FeedBurner feed.</p>", 'antileech'); ?>

		<?php _e("<p>In the Local Feed field, select the feed of your site that should redirect to a FeedBurner address.  In the FeedBurner field, put the URL of the FeedBurner feed that users will be redirected to.  You may enter multiple local URLs that all point to the same FeedBurner URL, but only one feedburner URL per local feed.  Remove the checkbox from the Active column to cancel the redirection.</p>", 'antileech'); ?>

		<?php
		
		$feeds = array(
			'*' => __('All Feeds'),
			'o' => __('Comment Feed'),
			'p' => __('Post Feeds'),
		);
		$cats = $wpdb->get_results("SELECT cat_ID, cat_name, category_nicename FROM {$wpdb->categories} WHERE cat_ID > 0");
		foreach($cats as $cat) {
			$feeds['c' . $cat->cat_ID] = sprintf(__("Category \"%s\" Feed", 'antileech'), $cat->cat_name);
		}
		ksort($feeds);
		foreach($feeds as $key => $feed) {
			$optionset .= "<option value=\"{$key}\">{$feed}</option>\n";
		}
		?>
		
		<table>
		<thead>
			<tr><th><?php _e("Active", 'antileech'); ?></th><th><?php _e("Local Feed", 'antileech'); ?></th><th><?php _e("FeedBurner URL", 'antileech'); ?></th></tr>
		</thead>
		<tbody>
		<?php
		
		foreach((array)$options['burnedfeeds'] as $local => $remote) {
			echo '<tr><td><input type="checkbox" checked="checked" name="feed[' . $local . ']" value="ok" /></td>';
			echo '<td>' . $feeds[$local] . '</td>';
			echo '<td>' . $remote . '</td></tr>';
		}
		
		?>
		
			<tr><td><input type="checkbox" checked="checked" disabled="disabled" /></td><td><select name="newlocalurl" ><?php echo $optionset; ?> </select></td><td><input type="text" name="newfburl" value="" size="35"/></td></tr>
		</tbody>
		</table> 
				
		</fieldset>
		<?php wp_nonce_field('antileech'); ?>
		<p class="submit"><input type="submit" name="submit" value="Update" /></p>
		</form>
		</div>	
			<?php
	}
	
	function post_link($link) {
		$options = get_option('antileech');

		if(($this->route == 1) && is_feed() && isset($options['nomainlink'])) {
			return 'http://google.com/';
		}
		return $link;
	}
	
	function option_rss_use_excerpt($value) {
		$options = get_option('antileech');
		if($options['contentis'] == 'truncated' && $this->route) return true;
		return $value;
	}
}

$antileech = new AntiLeech();

?>